import 'package:careerquest/page/home_page.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool isLogin = true;
  bool isPasswordVisible = false;
  final GlobalKey<FormState> _formkey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formkey,
        child: ListView(
          padding: EdgeInsets.symmetric(
              horizontal: MediaQuery.of(context).size.width / 8),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      _menuItem(title: 'Home'),
                      _menuItem(title: 'About us'),
                      _menuItem(title: 'Contact us'),
                      _menuItem(title: 'Help'),
                    ],
                  ),
                  Row(
                    children: [
                      _menuItem(title: 'Sign In', isActive: isLogin),
                      _menuItem(title: 'Register', isActive: !isLogin),
                    ],
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isLogin
                            ? 'Sign In to \nCareerQuest'
                            : 'Welcome to \nCareerQuest',
                        style: const TextStyle(
                          fontSize: 45,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      isLogin
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "If you don't have an account",
                                  style: TextStyle(
                                      color: Colors.black54,
                                      fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    const Text(
                                      "You can",
                                      style: TextStyle(
                                          color: Colors.black54,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    const SizedBox(width: 15),
                                    GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          isLogin = false;
                                          _formkey.currentState!.reset();
                                        });
                                      },
                                      child: const Text(
                                        "Register here!",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            )
                          : const Text(
                              "Ladder of Success Starts at your High School",
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontWeight: FontWeight.bold),
                            ),
                      Image.asset(
                        'images/illustration-2.png',
                        width: 300,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Image.asset(
                    'images/illustration-1.png',
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: MediaQuery.of(context).size.height / 6),
                    child: SizedBox(
                      width: 320,
                      child: _formLogin(context),
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _formLogin(BuildContext context) {
    return Column(children: [
      Visibility(
        visible: !isLogin,
        child: TextFormField(
          decoration: InputDecoration(
            hintText: 'Full name*',
            filled: true,
            fillColor: Colors.blueGrey[50],
            labelStyle: const TextStyle(fontSize: 12),
            contentPadding: const EdgeInsets.only(left: 30),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueGrey[50]!),
              borderRadius: BorderRadius.circular(15),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueGrey[50]!),
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          validator: (value) {
            if (value!.isEmpty) {
              return "Required field";
            }
            return null;
          },
        ),
      ),
      const SizedBox(height: 30),
      TextFormField(
        decoration: InputDecoration(
          hintText: 'Enter email*',
          filled: true,
          fillColor: Colors.blueGrey[50],
          labelStyle: const TextStyle(fontSize: 12),
          contentPadding: const EdgeInsets.only(left: 30),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blueGrey[50]!),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blueGrey[50]!),
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        validator: (value) {
          if (value!.isEmpty) {
            return "Required field";
          }
          return null;
        },
      ),
      const SizedBox(height: 30),
      TextFormField(
        obscureText: !isPasswordVisible,
        decoration: InputDecoration(
          hintText: 'Password*',
          counterText: isLogin ? 'Forgot password?' : "",
          suffixIcon: IconButton(
            onPressed: () {
              setState(() {
                isPasswordVisible = !isPasswordVisible;
              });
            },
            icon: Icon(
              isPasswordVisible
                  ? Icons.visibility
                  : Icons.visibility_off_outlined,
              color: Colors.grey,
            ),
          ),
          filled: true,
          fillColor: Colors.blueGrey[50],
          labelStyle: const TextStyle(fontSize: 12),
          contentPadding: const EdgeInsets.only(left: 30),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blueGrey[50]!),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blueGrey[50]!),
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        validator: (value) {
          if (value!.isEmpty) {
            return "Required field";
          }
          return null;
        },
      ),
      const SizedBox(height: 40),
      Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.deepPurple[100]!,
              spreadRadius: 10,
              blurRadius: 20,
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: () {
            if (_formkey.currentState!.validate()) {
              if (isLogin) {
                Navigator.push<void>(
                  context,
                  MaterialPageRoute<void>(
                    builder: (BuildContext context) => const HomePage(),
                  ),
                );
              } else {
                setState(() {
                  isLogin = true;
                });
              }
            }
          },
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.deepPurple,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          child: SizedBox(
            width: double.infinity,
            height: 50,
            child: Center(
              child: isLogin ? const Text("Sign In") : const Text("Register"),
            ),
          ),
        ),
      ),
      const SizedBox(height: 40),
    ]);
  }

  Widget _menuItem({
    String title = 'Title Menu',
    isActive = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 75),
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: Column(
          children: [
            InkWell(
              onTap: () {
                _formkey.currentState!.reset();
                if (title.replaceAll(" ", "").toLowerCase() == "signin") {
                  setState(() {
                    isLogin = true;
                  });
                } else if (title.toLowerCase().toLowerCase() == "register") {
                  setState(() {
                    isLogin = false;
                  });
                }
              },
              child: Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isActive ? Colors.deepPurple : Colors.grey,
                ),
              ),
            ),
            const SizedBox(
              height: 6,
            ),
            isActive
                ? Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.deepPurple,
                      borderRadius: BorderRadius.circular(30),
                    ),
                  )
                : const SizedBox()
          ],
        ),
      ),
    );
  }
}
