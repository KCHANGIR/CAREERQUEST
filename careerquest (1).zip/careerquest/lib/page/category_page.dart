import 'package:careerquest/model/category.dart';
import 'package:careerquest/model/option.dart';
import 'package:careerquest/model/question.dart';
import 'package:careerquest/widget/question_numbers_widget.dart';
import 'package:careerquest/widget/questions_widget.dart';
import 'package:flutter/material.dart';

late Question? question;

class CategoryPage extends StatefulWidget {
  final Category category;

  const CategoryPage({
    super.key,
    required this.category,
  });

  @override
  CategoryPageState createState() => CategoryPageState();
}

class CategoryPageState extends State<CategoryPage> {
  late PageController controller;

  @override
  void initState() {
    super.initState();

    controller = PageController();
    getQuestionDetails();
  }

  getQuestionDetails() {
    if (mounted) {
      setState(() {
        question = widget.category.questions.first;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(context),
      body: question == null
          ? const CircularProgressIndicator()
          : QuestionsWidget(
              category: widget.category,
              controller: controller,
              onChangedPage: (index) => nextQuestion(index: index),
              onClickedOption: selectOption,
            ),
    );
  }

  PreferredSizeWidget buildAppBar(context) => AppBar(
        title: Text(widget.category.categoryName),
        actions: const [
          Icon(Icons.filter_alt_outlined),
          SizedBox(width: 16),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(80),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: question == null
                ? const SizedBox.shrink()
                : QuestionNumbersWidget(
                    questions: widget.category.questions,
                    question: question!,
                    onClickedNumber: (index) =>
                        nextQuestion(index: index, jump: true),
                  ),
          ),
        ),
      );

  void selectOption(Option option) {
    if (question!.isLocked) {
      return;
    } else {
      setState(() {
        question!.isLocked = true;
        question!.selectedOption = option;
      });
    }
  }

  void nextQuestion({int? index, bool jump = false}) {
    final nextPage = controller.page! + 1;
    final indexPage = index ?? nextPage.toInt();

    setState(() {
      question = widget.category.questions[indexPage];
    });

    if (jump) {
      controller.jumpToPage(indexPage);
    }
  }
}
