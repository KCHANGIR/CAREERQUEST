import 'package:careerquest/page/select_user_launch_screen.dart';
import 'package:flutter/material.dart';

class LaunchScreen extends StatefulWidget {
  const LaunchScreen({Key? key}) : super(key: key);

  @override
  LaunchScreenState createState() => LaunchScreenState();
}

class LaunchScreenState extends State<LaunchScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Align(
            alignment: const AlignmentDirectional(0.00, 0.00),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/images/Group.jpg',
                width: 1458,
                height: 912,
                fit: BoxFit.fill,
              ),
            ),
          ),
          Align(
              alignment: const AlignmentDirectional(0.04, -0.08),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push<void>(
                    context,
                    MaterialPageRoute<void>(
                      builder: (BuildContext context) =>
                          const SelectUserTypeScreen(),
                    ),
                  );
                },
                child: const Text(
                  "Start Quiz",
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
