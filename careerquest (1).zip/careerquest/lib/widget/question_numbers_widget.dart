import 'package:careerquest/model/question.dart';
import 'package:careerquest/widget/timer.dart';
import 'package:flutter/material.dart';

class QuestionNumbersWidget extends StatefulWidget {
  final List<Question> questions;
  final Question question;
  final ValueChanged<int> onClickedNumber;

  const QuestionNumbersWidget({
    super.key,
    required this.questions,
    required this.question,
    required this.onClickedNumber,
  });

  @override
  State<QuestionNumbersWidget> createState() => _QuestionNumbersWidgetState();
}

class _QuestionNumbersWidgetState extends State<QuestionNumbersWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    const double padding = 16;

    return SizedBox(
      height: 50,
      child: Row(
        children: [
          Expanded(
            flex: 10,
            child: ListView.separated(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: padding),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) => Container(width: padding),
              itemCount: widget.questions.length,
              itemBuilder: (context, index) {
                final isSelected = widget.question == widget.questions[index];

                return buildNumber(index: index, isSelected: isSelected);
              },
            ),
          ),
          const Expanded(flex: 2, child: OtpTimer())
        ],
      ),
    );
  }

  Widget buildNumber({
    required int index,
    required bool isSelected,
  }) {
    final color = isSelected ? Colors.orange.shade300 : Colors.white;

    return GestureDetector(
      onTap: () => widget.onClickedNumber(index),
      child: CircleAvatar(
        backgroundColor: color,
        child: Text(
          '${index + 1}',
          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}
