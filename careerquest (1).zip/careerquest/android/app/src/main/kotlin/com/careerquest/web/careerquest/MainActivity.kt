package com.careerquest.web.careerquest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
